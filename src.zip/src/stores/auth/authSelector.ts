import { RootState } from "../redux";
export const selectToken = (state: RootState): string | undefined | object => {
    return state;
};
