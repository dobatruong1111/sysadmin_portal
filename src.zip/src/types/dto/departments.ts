type Departments = {
    id: number;
    name: string;
    code: string;
    under: string;
    status: boolean;
}