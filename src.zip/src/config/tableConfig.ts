/**
 * set min, max width for column 'STT' in table
 */
export const FIXED_WIDTH_COLUMN_STT = 50;
